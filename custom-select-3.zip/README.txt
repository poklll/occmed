A Pen created at CodePen.io. You can find this one at http://codepen.io/afalchi82/pen/aNXjgb.

 A jQuery custom select.